# Setup
This application has been configured to run on a local host, and requires Python and MySQL to be installed.

First time setup (Windows, database migration):
1. Open command prompt window
2. Run Software Design Project\software-design-project\Scripts\activate.bat
3. Run "python manage.py migrate"

Running the application (Windows):
1. Open command prompt window
2. Run Software Design Project\software-design-project\Scripts\activate.bat
3. Change terminal directory to Software Design Project\course_management_system
4. Run "python manage.py runserver"

# Demonstration of Use Cases (UC-1, UC-2, UC-7)

https://docs.google.com/document/d/1DT6v8h98p3SjGvRnFWlDC3WLfe4u_mevIR3W0HyaDu4/edit

# Main Implemented Pages:
## General
- /login
- /registration

## Student
- /join_course
- /view_course

## Staff
- /add_course
- /manage_course
- /edit_course
- /delete_course

Credit to [official Django documentation](https://docs.djangoproject.com/en/4.1/) and [NalinGoyal's article](https://www.geeksforgeeks.org/college-management-system-using-django-python-project/) in assisting the development of this application.
