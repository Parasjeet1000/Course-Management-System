from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib import messages
from django.core.files.storage import FileSystemStorage
from django.urls import reverse
import datetime
from ..models import CustomUser, Courses, Students, EnrolledCourse

def student_home(request):
        return render(request, "student_template/student_home_template.html")


def student_profile(request):
    user = CustomUser.objects.get(id=request.user.id)
    student = Students.objects.get(admin=user)

    context = {
        "user": user,
        "student": student
    }
    return render(request, 'student_template/student_profile.html', context)


def student_profile_update(request):
    if request.method != "POST":
        messages.error(request, "Invalid Method!")
        return redirect('student_profile')
    else:
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        password = request.POST.get('password')
        address = request.POST.get('address')

        try:
            customuser = CustomUser.objects.get(id=request.user.id)
            customuser.first_name = first_name
            customuser.last_name = last_name
            if password != None and password != "":
                customuser.set_password(password)
            customuser.save()

            student = Students.objects.get(admin=customuser.id)
            student.address = address
            student.save()

            messages.success(request, "Profile Updated Successfully")
            return redirect('student_profile')
        except:
            messages.error(request, "Failed to Update Profile")
            return redirect('student_profile')


def join_course(request):
    courses = Courses.objects.all()
    context = {
        "courses": courses,
    }
    return render(request, "student_template/join_course_template.html", context)


def join_course_save(request):
    if request.method != "POST":
        messages.error(request, "Invalid Method!")
        return redirect('join_course')
    else:
        course_id = request.POST.get('course')
        course = Courses.objects.get(id=course_id)

        user = CustomUser.objects.get(id=request.user.id)
        student = Students.objects.get(admin=user)
        try:
            course_model = EnrolledCourse(course_id=course, student_id=student)
            course_model.save()
            messages.success(request, "Course Joined Successfully!")
            return redirect('join_course')
        except:
            messages.error(request, "Failed to Join Course!")
            return redirect('join_course')


def view_course(request):
    enrollment = EnrolledCourse.objects.all()
    context = {
        "enrolledcourse": enrollment
    }
    return render(request, 'student_template/view_course_template.html', context)

def leave_course(request, enrollment_id):
    enrollment = EnrolledCourse.objects.get(id=enrollment_id)
    try:
        enrollment.delete()
        messages.success(request, "Left Course Successfully.")
        return redirect('view_course')
    except:
        messages.error(request, "Failed to Leave Course.")
        return redirect('view_course')
